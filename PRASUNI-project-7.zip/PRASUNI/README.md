# PRASUNI (v0.1.0 - early core)

Offline Android app (Kotlin + Jetpack Compose), package `com.prasuni.nursing`.

## Build the APK from your phone (free)
1. Create a free GitHub account and a new repository.
2. Upload all files of this project (keep the `.github/workflows/build.yml` path).
3. Open the repo > Actions > "Build debug APK" > Run workflow (it also runs on every upload).
4. When it finishes, open the run and download the artifact `prasuni-debug-apk`. Unzip, tap the APK, allow "install unknown apps".

Or open the folder in Android Studio and run Build > Build APK(s).

## Status (honest)
- NOT yet compiled or run: no Android SDK or network was available where this was written. The first build may show compile errors that need fixing.
- Question bank: 1,000 validated questions (250 per year), all needing educator review. 7 lessons (3 sample lessons + 4 general procedure pages). All content needs review by a qualified nursing educator.
- App layout follows the 5-tab design: Home (How it works), Select your year, Knowledge DNA, Practice questions, My progress. Doctor card (Sunitha Chauhan) at the end of Home.
- Done: logo/icon/splash, home with real stats and streak, 4 years, subjects, lessons with personal notes and completion, quiz with feedback, timed mock exam (20 questions), results review, retry wrong, bookmarks, flashcards, search, planner with daily goal, progress by year/subject, concept-level knowledge-gap diagnosis, previous-vs-latest comparison, recently viewed, clear data, privacy/about, "Created by Pranitha" footer.
- Not done: more lessons and procedures, reminders/notifications, Room database (SharedPreferences is used), signed release build.

## Add content
Edit `app/src/main/assets/content/questions.json` and `lessons.json` (same fields as existing items; `answer` is the 0-based index of the correct option).

## Signed release APK
Android Studio > Build > Generate Signed Bundle/APK > create a keystore and keep it safe (losing it blocks updates).
