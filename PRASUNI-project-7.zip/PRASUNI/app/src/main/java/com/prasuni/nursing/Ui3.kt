package com.prasuni.nursing

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

enum class NavTab(val label: String, val icon: String) {
    HOME("Home", "\uD83C\uDFE0"),
    YEAR("Select your year", "\uD83C\uDF93"),
    DNA("Knowledge DNA", "\uD83E\uDDEC"),
    PRACTICE("Practice questions", "\uD83D\uDCDD"),
    PROGRESS("My progress", "\uD83D\uDCC8")
}

@Composable
fun BottomNav(selected: NavTab, onSelect: (NavTab) -> Unit) {
    NavigationBar {
        NavTab.values().forEach { t ->
            NavigationBarItem(
                selected = t == selected,
                onClick = { onSelect(t) },
                icon = { Text(t.icon) },
                label = { Text(t.label, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 12.sp) }
            )
        }
    }
}

@Composable
fun AppHeader(onSearch: () -> Unit, onFlash: () -> Unit, onPlanner: () -> Unit, onBookmarks: () -> Unit, onAbout: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                OutlinedButton(onClick = { open = true }) { Text("\u2630") }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    DropdownMenuItem(text = { Text("Search") }, onClick = { open = false; onSearch() })
                    DropdownMenuItem(text = { Text("Flashcards") }, onClick = { open = false; onFlash() })
                    DropdownMenuItem(text = { Text("Study planner") }, onClick = { open = false; onPlanner() })
                    DropdownMenuItem(text = { Text("Bookmarks") }, onClick = { open = false; onBookmarks() })
                    DropdownMenuItem(text = { Text("Settings, privacy and about") }, onClick = { open = false; onAbout() })
                }
            }
            Spacer(Modifier.width(12.dp))
            Image(painterResource(R.drawable.prasuni_logo), "PRASUNI logo", Modifier.size(44.dp))
            Spacer(Modifier.width(8.dp))
            Text("PRASUNI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary, letterSpacing = 3.sp)
        }
    }
}

@Composable
fun Chip(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
        Text(text, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun StepRow(icon: String, title: String, desc: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer) {
            Text(icon, Modifier.padding(12.dp), fontSize = 20.sp)
        }
        Column(Modifier.padding(start = 12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(desc, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun HomeScreen(repo: Repo, onGoYear: () -> Unit, onGoDna: () -> Unit, onGoPractice: () -> Unit,
               onMixed: () -> Unit, onMock: () -> Unit, onRevise: () -> Unit, onPlanner: () -> Unit,
               onLesson: (Lesson) -> Unit) {
    val total = repo.questions.size
    val attempted = repo.attemptedQuestions()
    val acc = repo.accuracyPercent()
    val weak = repo.subjectsNeedingRevision()
    val missed = repo.questions.count { it.id in repo.missedQuestionIds() }
    val recent = repo.recentResults(3)
    val recentL = repo.recentLessons()
    val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            InfoCard {
                Text("Know exactly where you stand", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("PRASUNI finds the gaps in your B.Sc. Nursing knowledge, then helps you practise, retest and improve.")
                Spacer(Modifier.height(10.dp))
                Button(onClick = onGoYear, modifier = Modifier.fillMaxWidth()) { Text("Select your year") }
            }
        }
        item {
            InfoCard {
                Text("Your progress", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Questions available: $total")
                Text("Questions attempted: $attempted")
                Text(if (acc == null) "Correct answers: no attempts yet" else "Correct answers: $acc%")
                Text("Study streak: ${repo.streak()} day(s)")
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onMixed, enabled = total > 0, modifier = Modifier.weight(1f)) { Text("Mixed quiz") }
                Button(onClick = onMock, enabled = total > 0, modifier = Modifier.weight(1f)) { Text("Mock exam") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRevise, enabled = missed > 0, modifier = Modifier.weight(1f)) { Text("Revise mistakes ($missed)") }
                OutlinedButton(onClick = onPlanner, modifier = Modifier.weight(1f)) { Text("Study planner") }
            }
        }
        item {
            InfoCard {
                Text("How it works", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                StepRow("\uD83C\uDF93", "1. Select your year", "Choose Year 1 to 4 and open its subjects, lessons and questions.")
                StepRow("\uD83E\uDDEC", "2. Check your Knowledge DNA", "See which concepts you know and where the gaps are. Suggested prerequisite subjects lead you from basics to advanced topics.")
                StepRow("\uD83D\uDCDD", "3. Practice questions", "Learn, practise, retest and watch your accuracy actually improve.")
                StepRow("\uD83D\uDCC5", "4. Retest later", "Set a daily goal in your study planner, then retest and compare your results.")
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onGoDna, modifier = Modifier.weight(1f)) { Text("Knowledge DNA") }
                    OutlinedButton(onClick = onGoPractice, modifier = Modifier.weight(1f)) { Text("Practice") }
                }
            }
        }
        if (weak.isNotEmpty()) {
            item {
                InfoCard {
                    Text("Subjects needing revision", fontWeight = FontWeight.Bold)
                    Text("Shown when a subject has 3+ answers and under 60% correct.", style = MaterialTheme.typography.bodySmall)
                    weak.forEach { Text("- ${it.first}: ${it.second}% correct") }
                }
            }
        }
        if (recent.isNotEmpty()) {
            item {
                InfoCard {
                    Text("Recent quiz results", fontWeight = FontWeight.Bold)
                    recent.forEach { Text("${it.label}: ${it.correct}/${it.total}  (${df.format(Date(it.time))})") }
                }
            }
        }
        if (recentL.isNotEmpty()) {
            item {
                InfoCard {
                    Text("Recently viewed", fontWeight = FontWeight.Bold)
                    recentL.forEach { l -> TextButton(onClick = { onLesson(l) }) { Text(l.title) } }
                }
            }
        }
        item {
            InfoCard {
                Text("Telugu translations will be shown where available (none added yet).", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(DISCLAIMER)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Needs educator review")
                    Chip("Built for teacher review")
                    Chip("For education only")
                }
            }
        }
        item {
            InfoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.doctor_photo), "Doctor photo",
                        Modifier.size(88.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    Column(Modifier.padding(start = 16.dp)) {
                        Text("Doctor", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                        Text("Sunitha Chauhan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.prasuni_logo), "PRASUNI logo", Modifier.height(64.dp))
                Spacer(Modifier.height(8.dp))
                Text("Created by Pranitha", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun YearPickScreen(repo: Repo, onYear: (Int) -> Unit) {
    val mine = repo.myYear()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Select your year", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Choose your B.Sc. Nursing year to see its subjects. Subject names follow a common structure; verify them against the Indian Nursing Council curriculum and your university syllabus.", style = MaterialTheme.typography.bodySmall)
        }
        items((1..4).toList()) { y ->
            val n = repo.questions.count { it.year == y }
            InfoCard(onClick = { onYear(y) }) {
                Text("Year $y" + if (mine == y) "  (your year)" else "", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)
                Text("${repo.curriculum[y]?.size ?: 0} subjects  |  $n questions")
            }
        }
    }
}

@Composable
fun DnaScreen(repo: Repo, onQuiz: (String, List<Question>, Int) -> Unit, onLesson: (Lesson) -> Unit, onSubject: (Int, String) -> Unit) {
    var year by remember { mutableStateOf(repo.myYear()) }
    val subjects = repo.curriculum[year] ?: emptyList()
    val subj = repo.statsBy { "${it.year}|${it.subject}" }
    val conc = repo.statsBy { "${it.year}|${it.subject}|${it.concept}" }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Knowledge DNA", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Your Knowledge DNA shows, concept by concept, what you know and where the gaps are. It is built only from your real answers: Strong 80% or more, Developing 60-79%, Needs revision under 60%.", style = MaterialTheme.typography.bodySmall)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..4).forEach { y ->
                    if (y == year) Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("Y$y") }
                    else OutlinedButton(onClick = { year = y; repo.setMyYear(y) }, modifier = Modifier.weight(1f)) { Text("Y$y") }
                }
            }
        }
        items(subjects) { name ->
            val qs = repo.questions.filter { it.year == year && it.subject == name }
            val st = subj["$year|$name"]
            val concepts = qs.map { it.concept }.distinct()
            val weakSet = concepts.filter { c -> (conc["$year|$name|$c"]?.let { it.attempts > 0 && it.pct < 60 }) == true }.toSet()
            InfoCard {
                Text(name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                if (qs.isEmpty()) {
                    Text("No questions for this subject yet.", style = MaterialTheme.typography.bodySmall)
                } else if (st == null) {
                    Text("Not assessed yet. ${qs.size} questions available.")
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { onQuiz("Diagnostic: $name", qs, 5) }, modifier = Modifier.fillMaxWidth()) { Text("Start diagnostic (5 questions)") }
                } else {
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(progress = { st.pct / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("${st.pct}% correct (${st.correct}/${st.attempts} answers)", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(6.dp))
                    concepts.forEach { c ->
                        val cs = conc["$year|$name|$c"]
                        val status = when {
                            cs == null || cs.attempts == 0 -> "Not started"
                            cs.pct < 60 -> "Needs revision (${cs.pct}%)"
                            cs.pct < 80 -> "Developing (${cs.pct}%)"
                            else -> "Strong (${cs.pct}%)"
                        }
                        Text("- $c: $status", style = MaterialTheme.typography.bodySmall)
                    }
                    if (weakSet.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Gaps found. Practise these concepts, and revise the suggested prerequisite subjects first:", fontWeight = FontWeight.SemiBold)
                        repo.prerequisites(name).forEach { p ->
                            val py = repo.yearOf(p)
                            val ps = subj["$py|$p"]
                            TextButton(onClick = { onSubject(py, p) }) { Text("Revise first: $p" + if (ps == null) " (not assessed)" else " (${ps.pct}% correct)") }
                        }
                        Button(onClick = { onQuiz("Weak concepts: $name", qs.filter { it.concept in weakSet }, 10) }, modifier = Modifier.fillMaxWidth()) { Text("Practise weak concepts") }
                        repo.lessons.filter { it.year == year && it.subject == name }.forEach { l ->
                            TextButton(onClick = { onLesson(l) }) { Text("Lesson: ${l.title}") }
                        }
                    } else {
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(onClick = { onQuiz(name, qs, 10) }, modifier = Modifier.fillMaxWidth()) { Text("Practise this subject") }
                    }
                }
            }
        }
    }
}

@Composable
fun PracticeScreen(repo: Repo, onQuiz: (String, List<Question>, Int, Boolean) -> Unit, onFlash: (String, List<Question>) -> Unit) {
    var len by remember { mutableStateOf(10) }
    var year by remember { mutableStateOf(repo.myYear()) }
    val missed = repo.questions.filter { it.id in repo.missedQuestionIds() }
    val yearQs = repo.questions.filter { it.year == year }
    val subjects = (repo.curriculum[year] ?: emptyList()).filter { s -> yearQs.any { it.subject == s } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Practice questions", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Learn, practise, retest and watch your accuracy actually improve.", style = MaterialTheme.typography.bodySmall)
        }
        item {
            InfoCard {
                Text("Number of questions", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5, 10, 20, 30).forEach { n ->
                        if (len == n) Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("$n") }
                        else OutlinedButton(onClick = { len = n }, modifier = Modifier.weight(1f)) { Text("$n") }
                    }
                }
            }
        }
        item {
            InfoCard {
                Text("Quick practice", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Button(onClick = { onQuiz("Mixed quiz", repo.questions, len, false) }, modifier = Modifier.fillMaxWidth()) { Text("Mixed quiz ($len questions)") }
                OutlinedButton(onClick = { onQuiz("Mock exam (timed)", repo.questions, len, true) }, modifier = Modifier.fillMaxWidth()) { Text("Timed mock exam ($len questions)") }
                OutlinedButton(onClick = { onQuiz("Revise mistakes", missed, len, false) }, enabled = missed.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Revise mistakes (${missed.size})") }
                OutlinedButton(onClick = { onFlash("Flashcards: all subjects", repo.questions) }, modifier = Modifier.fillMaxWidth()) { Text("Flashcards") }
            }
        }
        item {
            InfoCard {
                Text("Practise by year and subject", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..4).forEach { y ->
                        if (y == year) Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("Y$y") }
                        else OutlinedButton(onClick = { year = y }, modifier = Modifier.weight(1f)) { Text("Y$y") }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Button(onClick = { onQuiz("Year $year quiz", yearQs, len, false) }, enabled = yearQs.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Year $year mixed (${yearQs.size} available)") }
                subjects.forEach { s ->
                    val n = yearQs.count { it.subject == s }
                    OutlinedButton(onClick = { onQuiz(s, yearQs.filter { it.subject == s }, len, false) }, modifier = Modifier.fillMaxWidth()) { Text("$s ($n)") }
                }
            }
        }
    }
}
