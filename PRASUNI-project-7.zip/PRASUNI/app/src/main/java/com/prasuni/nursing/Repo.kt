package com.prasuni.nursing

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Question(
    val id: String, val year: Int, val subject: String, val topic: String, val text: String,
    val options: List<String>, val answer: Int, val explanation: String,
    val difficulty: String, val concept: String, val reference: String,
    val textTe: String = "", val explanationTe: String = ""
)

data class Lesson(
    val id: String, val year: Int, val subject: String, val title: String, val status: String,
    val objectives: List<String>, val body: String, val keyPoints: List<String>
)

data class QuizResult(val time: Long, val label: String, val total: Int, val correct: Int)

/** Shuffles option order and remaps the correct answer index. */
fun Question.withShuffledOptions(): Question {
    val correct = options[answer]
    val shuffled = options.shuffled()
    return copy(options = shuffled, answer = shuffled.indexOf(correct))
}

data class Stat(val attempts: Int, val correct: Int) {
    val pct: Int get() = if (attempts == 0) -1 else correct * 100 / attempts
}

class Repo(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("prasuni", Context.MODE_PRIVATE)
    val questions: List<Question> = loadQuestions(ctx)
    val lessons: List<Lesson> = loadLessons(ctx)
    val curriculum: Map<Int, List<String>> = loadCurriculum(ctx)
    private val prereq: Map<String, List<String>> = loadPrereq(ctx)

    private fun read(ctx: Context, name: String): String =
        ctx.assets.open("content/$name").bufferedReader().use { it.readText() }

    private fun strings(a: JSONArray): List<String> = List(a.length()) { a.getString(it) }

    private fun loadQuestions(ctx: Context): List<Question> = try {
        val a = JSONArray(read(ctx, "questions.json"))
        List(a.length()) {
            val o = a.getJSONObject(it)
            Question(o.getString("id"), o.getInt("year"), o.getString("subject"), o.getString("topic"),
                o.getString("text"), strings(o.getJSONArray("options")), o.getInt("answer"),
                o.getString("explanation"), o.getString("difficulty"), o.getString("concept"),
                o.getString("reference"), o.optString("textTe", ""), o.optString("explanationTe", ""))
        }
    } catch (e: Exception) { emptyList() }

    private fun loadLessons(ctx: Context): List<Lesson> = try {
        val a = JSONArray(read(ctx, "lessons.json"))
        List(a.length()) {
            val o = a.getJSONObject(it)
            Lesson(o.getString("id"), o.getInt("year"), o.getString("subject"), o.getString("title"),
                o.getString("status"), strings(o.getJSONArray("objectives")), o.getString("body"),
                strings(o.getJSONArray("keyPoints")))
        }
    } catch (e: Exception) { emptyList() }

    private fun loadCurriculum(ctx: Context): Map<Int, List<String>> = try {
        val o = JSONObject(read(ctx, "curriculum.json"))
        (1..4).associateWith { y -> strings(o.getJSONArray(y.toString())) }
    } catch (e: Exception) { (1..4).associateWith { emptyList<String>() } }

    // ---- answer statistics: id -> [attempts, correct, lastWasCorrect(1/0)] ----
    private fun stats(): JSONObject =
        try { JSONObject(prefs.getString("stats", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun recordAnswer(id: String, correct: Boolean) {
        val s = stats()
        val a = s.optJSONArray(id)
        val att = (a?.optInt(0) ?: 0) + 1
        val cor = (a?.optInt(1) ?: 0) + if (correct) 1 else 0
        s.put(id, JSONArray(listOf(att, cor, if (correct) 1 else 0)))
        prefs.edit().putString("stats", s.toString()).apply()
        logActivity()
    }

    fun attemptedQuestions(): Int = stats().length()

    fun accuracyPercent(): Int? {
        val s = stats(); var att = 0; var cor = 0
        for (k in s.keys()) { val a = s.getJSONArray(k); att += a.getInt(0); cor += a.getInt(1) }
        return if (att == 0) null else cor * 100 / att
    }

    fun missedQuestionIds(): Set<String> {
        val s = stats()
        return s.keys().asSequence().filter { s.getJSONArray(it).getInt(2) == 0 }.toSet()
    }

    /** Transparent rule: subject has >= 3 recorded answers and accuracy below 60%. */
    fun subjectsNeedingRevision(): List<Pair<String, Int>> {
        val s = stats(); val att = HashMap<String, Int>(); val cor = HashMap<String, Int>()
        for (q in questions) {
            val a = s.optJSONArray(q.id) ?: continue
            att[q.subject] = (att[q.subject] ?: 0) + a.getInt(0)
            cor[q.subject] = (cor[q.subject] ?: 0) + a.getInt(1)
        }
        return att.filter { it.value >= 3 && (cor[it.key] ?: 0) * 100 / it.value < 60 }
            .map { it.key to (cor[it.key] ?: 0) * 100 / it.value }
    }

    // ---- bookmarks ----
    fun bookmarks(): Set<String> = prefs.getStringSet("bookmarks", emptySet())?.toSet() ?: emptySet()
    fun toggleBookmark(id: String) {
        val b = bookmarks().toMutableSet()
        if (!b.add(id)) b.remove(id)
        prefs.edit().putStringSet("bookmarks", b).apply()
    }

    // ---- history ----
    fun addResult(label: String, total: Int, correct: Int) {
        val old = try { JSONArray(prefs.getString("history", "[]")) } catch (e: Exception) { JSONArray() }
        val list = JSONArray()
        list.put(JSONObject().put("t", System.currentTimeMillis()).put("l", label).put("n", total).put("c", correct))
        for (i in 0 until minOf(old.length(), 29)) list.put(old.get(i))
        prefs.edit().putString("history", list.toString()).apply()
    }

    fun recentResults(n: Int): List<QuizResult> = try {
        val a = JSONArray(prefs.getString("history", "[]"))
        List(minOf(n, a.length())) {
            val o = a.getJSONObject(it)
            QuizResult(o.getLong("t"), o.getString("l"), o.getInt("n"), o.getInt("c"))
        }
    } catch (e: Exception) { emptyList() }

    // ---- activity, goals, streak (based on real recorded answers) ----
    private fun fmt() = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    private fun today(): String = fmt().format(java.util.Date())
    private fun logActivity() {
        val t = today()
        val days = (prefs.getStringSet("days", emptySet()) ?: emptySet()).toMutableSet()
        days.add(t)
        val cnt = if (prefs.getString("todayDate", "") == t) prefs.getInt("todayCount", 0) + 1 else 1
        prefs.edit().putStringSet("days", days).putString("todayDate", t).putInt("todayCount", cnt).apply()
    }
    fun answeredToday(): Int = if (prefs.getString("todayDate", "") == today()) prefs.getInt("todayCount", 0) else 0
    fun dailyGoal(): Int = prefs.getInt("goal", 10)
    fun setDailyGoal(n: Int) { prefs.edit().putInt("goal", n).apply() }
    fun activeDays(): Int = (prefs.getStringSet("days", emptySet()) ?: emptySet()).size
    fun streak(): Int {
        val days = prefs.getStringSet("days", emptySet()) ?: emptySet()
        val f = fmt(); val cal = java.util.Calendar.getInstance()
        if (f.format(cal.time) !in days) cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (f.format(cal.time) in days) { n++; cal.add(java.util.Calendar.DAY_OF_YEAR, -1) }
        return n
    }

    // ---- notes, completed lessons, recently viewed ----
    private fun notesObj(): JSONObject =
        try { JSONObject(prefs.getString("notes", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
    fun getNote(id: String): String = notesObj().optString(id, "")
    fun setNote(id: String, text: String) {
        val o = notesObj()
        if (text.isBlank()) o.remove(id) else o.put(id, text)
        prefs.edit().putString("notes", o.toString()).apply()
    }
    fun isDone(id: String): Boolean = id in (prefs.getStringSet("done", emptySet()) ?: emptySet())
    fun toggleDone(id: String) {
        val d = (prefs.getStringSet("done", emptySet()) ?: emptySet()).toMutableSet()
        if (!d.add(id)) d.remove(id)
        prefs.edit().putStringSet("done", d).apply()
    }
    fun doneCount(): Int = lessons.count { isDone(it.id) }
    fun addRecent(id: String) {
        val cur = (prefs.getString("recent", "") ?: "").split(",").filter { it.isNotBlank() && it != id }
        prefs.edit().putString("recent", (listOf(id) + cur).take(5).joinToString(",")).apply()
    }
    fun recentLessons(): List<Lesson> =
        (prefs.getString("recent", "") ?: "").split(",").mapNotNull { id -> lessons.firstOrNull { it.id == id } }

    // ---- statistics by group ----
    fun statsBy(key: (Question) -> String): Map<String, Stat> {
        val s = stats(); val m = HashMap<String, IntArray>()
        for (q in questions) {
            val a = s.optJSONArray(q.id) ?: continue
            val r = m.getOrPut(key(q)) { IntArray(2) }
            r[0] += a.getInt(0); r[1] += a.getInt(1)
        }
        return m.mapValues { Stat(it.value[0], it.value[1]) }
    }
    fun attemptedInYear(y: Int): Int { val s = stats(); return questions.count { it.year == y && s.has(it.id) } }
    /** Transparent rule: a concept with 2+ recorded answers and under 60% correct is a knowledge gap. */
    fun weakConcepts(): List<Pair<String, Int>> =
        statsBy { it.concept }.filter { it.value.attempts >= 2 && it.value.pct < 60 }.map { it.key to it.value.pct }

    // ---- search ----
    fun searchQuestions(query: String): List<Question> {
        val k = query.trim().lowercase(); if (k.length < 2) return emptyList()
        return questions.filter { (it.text + " " + it.topic + " " + it.subject + " " + it.concept).lowercase().contains(k) }
    }
    fun searchLessons(query: String): List<Lesson> {
        val k = query.trim().lowercase(); if (k.length < 2) return emptyList()
        return lessons.filter { (it.title + " " + it.subject + " " + it.body).lowercase().contains(k) }
    }

    private fun loadPrereq(ctx: Context): Map<String, List<String>> = try {
        val o = JSONObject(read(ctx, "prerequisites.json"))
        o.keys().asSequence().associateWith { strings(o.getJSONArray(it)) }
    } catch (e: Exception) { emptyMap() }

    /** Suggested prerequisite subjects (educational judgement; verify against your syllabus). */
    fun prerequisites(subject: String): List<String> = prereq[subject] ?: emptyList()
    fun yearOf(subject: String): Int = curriculum.entries.firstOrNull { subject in it.value }?.key ?: 1

    // ---- selected year and language ----
    fun myYear(): Int = prefs.getInt("myYear", 1)
    fun setMyYear(y: Int) { prefs.edit().putInt("myYear", y).apply() }
    fun teluguOn(): Boolean = prefs.getBoolean("telugu", false)
    fun setTelugu(b: Boolean) { prefs.edit().putBoolean("telugu", b).apply() }

    fun clearAllPersonalData() { prefs.edit().clear().apply() }
}
