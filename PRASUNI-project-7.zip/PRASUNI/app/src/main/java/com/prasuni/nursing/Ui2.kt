package com.prasuni.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SearchScreen(repo: Repo, onBack: () -> Unit, onLesson: (Lesson) -> Unit) {
    var query by remember { mutableStateOf("") }
    val lessons = repo.searchLessons(query)
    val qs = repo.searchQuestions(query)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { TopBar("Search", onBack) }
        item {
            OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("Subject, topic or keyword") }, modifier = Modifier.fillMaxWidth())
        }
        if (query.trim().length < 2) {
            item { Text("Type at least 2 letters to search lessons and questions.") }
        } else if (lessons.isEmpty() && qs.isEmpty()) {
            item { Text("No results for \"$query\".") }
        }
        items(lessons) { l ->
            InfoCard(onClick = { onLesson(l) }) {
                Text("Lesson: ${l.title}", fontWeight = FontWeight.Bold)
                Text("${l.subject} (Year ${l.year})", style = MaterialTheme.typography.bodySmall)
            }
        }
        items(qs) { q ->
            var show by remember { mutableStateOf(false) }
            InfoCard(onClick = { show = !show }) {
                Text("${q.subject} - ${q.topic} (Year ${q.year})", style = MaterialTheme.typography.bodySmall)
                Text(q.text, fontWeight = FontWeight.SemiBold)
                if (show) {
                    Spacer(Modifier.height(6.dp))
                    Text("Answer: ${q.options[q.answer]}", fontWeight = FontWeight.Bold)
                    Text(q.explanation, style = MaterialTheme.typography.bodySmall)
                } else {
                    Text("Tap to show answer", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun FlashScreen(title: String, cards: List<Question>, onBack: () -> Unit) {
    var i by remember { mutableStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    val q = cards[i]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(title, onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Card ${i + 1} of ${cards.size}  |  ${q.subject}", style = MaterialTheme.typography.labelLarge)
            InfoCard {
                Text("Question", style = MaterialTheme.typography.bodySmall)
                Text(q.text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            if (revealed) {
                InfoCard {
                    Text("Answer", style = MaterialTheme.typography.bodySmall)
                    Text(q.options[q.answer], style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(q.explanation)
                }
            } else {
                Button(onClick = { revealed = true }, modifier = Modifier.fillMaxWidth()) { Text("Reveal answer") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { i--; revealed = false }, enabled = i > 0, modifier = Modifier.weight(1f)) { Text("Previous") }
                Button(onClick = { i++; revealed = false }, enabled = i < cards.size - 1, modifier = Modifier.weight(1f)) { Text("Next") }
            }
            if (i == cards.size - 1) Text("End of this revision set.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ProgressScreen(repo: Repo, onBack: (() -> Unit)?, onQuiz: (String, List<Question>, Int) -> Unit,
                   onFlash: (String, List<Question>) -> Unit, onLesson: (Lesson) -> Unit) {
    val bySubject = repo.statsBy { it.subject }
    val weak = repo.weakConcepts()
    val weakNames = weak.map { it.first }.toSet()
    val weakQs = repo.questions.filter { it.concept in weakNames }
    val weakSubjects = weakQs.map { it.subject }.toSet()
    val recLessons = repo.lessons.filter { it.subject in weakSubjects }
    val compare = repo.recentResults(30).groupBy { it.label }.filter { it.value.size >= 2 }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("My progress", onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard {
                Text("By academic year", fontWeight = FontWeight.Bold)
                for (y in 1..4) {
                    val total = repo.questions.count { it.year == y }
                    Text("Year $y: ${repo.attemptedInYear(y)} of $total questions attempted")
                }
            }
            InfoCard {
                Text("By subject (only subjects you have answered)", fontWeight = FontWeight.Bold)
                if (bySubject.isEmpty()) Text("No answers recorded yet. Take a quiz to see your results here.")
                bySubject.entries.sortedBy { it.key }.forEach { (name, st) ->
                    Text("$name: ${st.pct}% correct (${st.correct}/${st.attempts} answers)")
                }
            }
            InfoCard {
                Text("Knowledge-gap diagnosis", fontWeight = FontWeight.Bold)
                Text("Rule: a concept with 2 or more answers and under 60% correct is flagged.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                if (weak.isEmpty()) Text("No gaps flagged yet. Answer more questions to get a diagnosis.")
                weak.forEach { Text("- ${it.first}: ${it.second}% correct") }
                if (weak.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onQuiz("Weak concepts", weakQs, 10) }, modifier = Modifier.fillMaxWidth()) { Text("Practise weak concepts") }
                    OutlinedButton(onClick = { onFlash("Weak concept flashcards", weakQs) }, modifier = Modifier.fillMaxWidth()) { Text("Flashcards for weak concepts") }
                    if (recLessons.isNotEmpty()) {
                        Text("Recommended lessons", fontWeight = FontWeight.Bold)
                        recLessons.forEach { l -> TextButton(onClick = { onLesson(l) }) { Text(l.title) } }
                    } else {
                        Text("No lessons exist yet for these subjects.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            InfoCard {
                Text("Previous vs latest result", fontWeight = FontWeight.Bold)
                if (compare.isEmpty()) Text("Repeat a quiz to compare your results.")
                compare.forEach { (label, list) ->
                    val latest = list[0]; val prev = list[1]
                    val a = if (prev.total == 0) 0 else prev.correct * 100 / prev.total
                    val b = if (latest.total == 0) 0 else latest.correct * 100 / latest.total
                    Text("$label: $a% -> $b%")
                }
            }
        }
    }
}

@Composable
fun PlannerScreen(repo: Repo, onBack: () -> Unit, onQuiz: (String, List<Question>, Int) -> Unit, onLesson: (Lesson) -> Unit) {
    var goal by remember { mutableStateOf(repo.dailyGoal()) }
    val today = repo.answeredToday()
    val remaining = maxOf(goal - today, 0)
    val missed = repo.questions.filter { it.id in repo.missedQuestionIds() }
    val nextLesson = repo.lessons.firstOrNull { !repo.isDone(it.id) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Study planner", onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard {
                Text("Daily goal (questions per day)", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5, 10, 20, 30).forEach { g ->
                        if (goal == g) Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("$g") }
                        else OutlinedButton(onClick = { goal = g; repo.setDailyGoal(g) }, modifier = Modifier.weight(1f)) { Text("$g") }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Today: $today of $goal answered")
                LinearProgressIndicator(progress = { minOf(1f, today / goal.toFloat()) }, modifier = Modifier.fillMaxWidth())
            }
            InfoCard {
                Text("Your record", fontWeight = FontWeight.Bold)
                Text("Current streak: ${repo.streak()} day(s)")
                Text("Days you studied: ${repo.activeDays()}")
                Text("Lessons completed: ${repo.doneCount()} of ${repo.lessons.size}")
            }
            InfoCard {
                Text("Today's plan", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (remaining > 0) {
                    Text("1. Answer $remaining more question(s) to reach your goal.")
                    Button(onClick = { onQuiz("Daily practice", repo.questions, remaining) }, modifier = Modifier.fillMaxWidth()) { Text("Start practice") }
                } else {
                    Text("1. Daily goal reached.")
                }
                Spacer(Modifier.height(6.dp))
                if (missed.isNotEmpty()) {
                    Text("2. Revise ${missed.size} question(s) you last got wrong.")
                    OutlinedButton(onClick = { onQuiz("Revise mistakes", missed, 10) }, modifier = Modifier.fillMaxWidth()) { Text("Revise mistakes") }
                } else {
                    Text("2. No missed questions to revise.")
                }
                Spacer(Modifier.height(6.dp))
                if (nextLesson != null) {
                    Text("3. Read a lesson: ${nextLesson.title}")
                    OutlinedButton(onClick = { onLesson(nextLesson) }, modifier = Modifier.fillMaxWidth()) { Text("Open lesson") }
                } else {
                    Text("3. All available lessons completed.")
                }
            }
            Text("Reminders and notifications are not available in this version.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
