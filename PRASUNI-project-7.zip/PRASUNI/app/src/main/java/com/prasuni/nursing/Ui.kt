package com.prasuni.nursing

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

sealed class Screen {
    object Home : Screen()
    object YearPickS : Screen()
    object DnaS : Screen()
    object PracticeS : Screen()
    data class YearS(val y: Int) : Screen()
    data class SubjectS(val y: Int, val subject: String) : Screen()
    data class LessonS(val lesson: Lesson) : Screen()
    data class QuizS(val label: String, val qs: List<Question>, val timeLimit: Int = 0) : Screen()
    data class ResultS(val label: String, val qs: List<Question>, val picked: List<Int>) : Screen()
    data class FlashS(val title: String, val qs: List<Question>) : Screen()
    object SearchS : Screen()
    object ProgressS : Screen()
    object PlannerS : Screen()
    object BookmarksS : Screen()
    object AboutS : Screen()
}

const val DISCLAIMER = "PRASUNI is for education only. It does not replace clinical judgement, supervised training, " +
    "emergency services or professional medical advice. Follow your institution's current policy."

@Composable
fun App(repo: Repo) {
    var tab by remember { mutableStateOf(NavTab.HOME) }
    var stack by remember { mutableStateOf(listOf<Screen>(Screen.Home)) }
    fun rootOf(t: NavTab): Screen = when (t) {
        NavTab.HOME -> Screen.Home
        NavTab.YEAR -> Screen.YearPickS
        NavTab.DNA -> Screen.DnaS
        NavTab.PRACTICE -> Screen.PracticeS
        NavTab.PROGRESS -> Screen.ProgressS
    }
    fun push(s: Screen) { stack = stack + s }
    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }
    fun goTab(t: NavTab) { tab = t; stack = listOf(rootOf(t)) }
    fun goHome() { goTab(NavTab.HOME) }
    fun quiz(label: String, pool: List<Question>, n: Int = 10, timed: Boolean = false) {
        val qs = pool.shuffled().take(n).map { it.withShuffledOptions() }
        if (qs.isNotEmpty()) push(Screen.QuizS(label, qs, if (timed) qs.size * 90 else 0))
    }
    fun flash(title: String, pool: List<Question>) {
        if (pool.isNotEmpty()) push(Screen.FlashS(title, pool.shuffled().take(20)))
    }
    BackHandler(enabled = stack.size > 1 || tab != NavTab.HOME) {
        if (stack.size > 1) pop() else goTab(NavTab.HOME)
    }
    val backOrNull: (() -> Unit)? = if (stack.size > 1) ({ pop() }) else null
    val cur = stack.last()

    Scaffold(
        topBar = {
            if (stack.size == 1) AppHeader(
                onSearch = { push(Screen.SearchS) },
                onFlash = { flash("Flashcards: all subjects", repo.questions) },
                onPlanner = { push(Screen.PlannerS) },
                onBookmarks = { push(Screen.BookmarksS) },
                onAbout = { push(Screen.AboutS) })
        },
        bottomBar = { if (cur !is Screen.QuizS) BottomNav(tab) { goTab(it) } }
    ) { pad ->
        Surface(Modifier.fillMaxSize().padding(pad), color = MaterialTheme.colorScheme.background) {
            when (val s = cur) {
                is Screen.Home -> HomeScreen(repo,
                    onGoYear = { goTab(NavTab.YEAR) },
                    onGoDna = { goTab(NavTab.DNA) },
                    onGoPractice = { goTab(NavTab.PRACTICE) },
                    onMixed = { quiz("Mixed quiz", repo.questions) },
                    onMock = { quiz("Mock exam (timed)", repo.questions, 20, true) },
                    onRevise = { quiz("Revise mistakes", repo.questions.filter { it.id in repo.missedQuestionIds() }) },
                    onPlanner = { push(Screen.PlannerS) },
                    onLesson = { push(Screen.LessonS(it)) })
                is Screen.YearPickS -> YearPickScreen(repo) { y -> repo.setMyYear(y); push(Screen.YearS(y)) }
                is Screen.DnaS -> DnaScreen(repo,
                    onQuiz = { label, pool, n -> quiz(label, pool, n) },
                    onLesson = { push(Screen.LessonS(it)) },
                    onSubject = { y, name -> push(Screen.SubjectS(y, name)) })
                is Screen.PracticeS -> PracticeScreen(repo,
                    onQuiz = { label, pool, n, timed -> quiz(label, pool, n, timed) },
                    onFlash = { title, pool -> flash(title, pool) })
                is Screen.YearS -> YearScreen(repo, s.y, ::pop,
                    onSubject = { push(Screen.SubjectS(s.y, it)) },
                    onYearQuiz = { quiz("Year ${s.y} quiz", repo.questions.filter { q -> q.year == s.y }) })
                is Screen.SubjectS -> SubjectScreen(repo, s.y, s.subject, ::pop,
                    onLesson = { push(Screen.LessonS(it)) },
                    onQuiz = { quiz(s.subject, repo.questions.filter { q -> q.year == s.y && q.subject == s.subject }) },
                    onFlash = { flash(s.subject, repo.questions.filter { q -> q.year == s.y && q.subject == s.subject }) })
                is Screen.LessonS -> LessonScreen(repo, s.lesson, ::pop)
                is Screen.QuizS -> QuizScreen(repo, s.label, s.qs, s.timeLimit, ::pop) { picked ->
                    stack = stack.dropLast(1) + Screen.ResultS(s.label, s.qs, picked)
                }
                is Screen.ResultS -> ResultScreen(s.label, s.qs, s.picked, ::goHome,
                    onRetryWrong = {
                        val wrong = s.qs.filterIndexed { i, q -> s.picked[i] != q.answer }
                        stack = stack.dropLast(1) + Screen.QuizS("Retry: ${s.label}", wrong.shuffled().map { it.withShuffledOptions() })
                    })
                is Screen.FlashS -> FlashScreen(s.title, s.qs, ::pop)
                is Screen.SearchS -> SearchScreen(repo, ::pop) { push(Screen.LessonS(it)) }
                is Screen.ProgressS -> ProgressScreen(repo, backOrNull,
                    onQuiz = { label, pool, n -> quiz(label, pool, n) },
                    onFlash = { title, pool -> flash(title, pool) },
                    onLesson = { push(Screen.LessonS(it)) })
                is Screen.PlannerS -> PlannerScreen(repo, ::pop,
                    onQuiz = { label, pool, n -> quiz(label, pool, n) },
                    onLesson = { push(Screen.LessonS(it)) })
                is Screen.BookmarksS -> BookmarksScreen(repo, ::pop)
                is Screen.AboutS -> AboutScreen(repo, ::pop, ::goHome)
            }
        }
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) TextButton(onClick = onBack) { Text("< Back") }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
fun InfoCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val m = if (onClick != null) modifier.clickable { onClick() } else modifier
    Card(m.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun YearScreen(repo: Repo, y: Int, onBack: () -> Unit, onSubject: (String) -> Unit, onYearQuiz: () -> Unit) {
    val subjects = repo.curriculum[y] ?: emptyList()
    val yearQs = repo.questions.filter { it.year == y }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { TopBar("Year $y", onBack) }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Subject names follow a common structure. Verify them against the Indian Nursing Council curriculum and your university syllabus.", style = MaterialTheme.typography.bodySmall)
                Button(onClick = onYearQuiz, enabled = yearQs.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Practice quiz for Year $y") }
            }
        }
        items(subjects) { subj ->
            val qn = repo.questions.count { it.year == y && it.subject == subj }
            val ln = repo.lessons.count { it.year == y && it.subject == subj }
            Box(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                InfoCard(onClick = { onSubject(subj) }) {
                    Text(subj, fontWeight = FontWeight.Bold)
                    Text("$ln lessons  |  $qn questions", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun SubjectScreen(repo: Repo, y: Int, subject: String, onBack: () -> Unit, onLesson: (Lesson) -> Unit,
                  onQuiz: () -> Unit, onFlash: () -> Unit) {
    val lessons = repo.lessons.filter { it.year == y && it.subject == subject }
    val qn = repo.questions.count { it.year == y && it.subject == subject }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(subject, onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onQuiz, enabled = qn > 0, modifier = Modifier.fillMaxWidth()) { Text("Practice quiz ($qn questions available)") }
            OutlinedButton(onClick = onFlash, enabled = qn > 0, modifier = Modifier.fillMaxWidth()) { Text("Flashcards") }
            if (qn == 0) Text("No questions for this subject yet. Verified content is still to be added.")
            Text("Lessons", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (lessons.isEmpty()) Text("No lessons for this subject yet. Verified content is still to be added.")
            lessons.forEach { l ->
                InfoCard(onClick = { onLesson(l) }) {
                    Text(l.title + if (repo.isDone(l.id)) "  (completed)" else "", fontWeight = FontWeight.Bold)
                    Text(l.status, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun LessonScreen(repo: Repo, l: Lesson, onBack: () -> Unit) {
    var note by remember { mutableStateOf(repo.getNote(l.id)) }
    var done by remember { mutableStateOf(repo.isDone(l.id)) }
    var saved by remember { mutableStateOf(false) }
    LaunchedEffect(l.id) { repo.addRecent(l.id) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(l.title, onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Status: ${l.status}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            Text("Learning objectives", fontWeight = FontWeight.Bold)
            l.objectives.forEach { Text("- $it") }
            Text("Notes", fontWeight = FontWeight.Bold)
            Text(l.body)
            Text("Key points", fontWeight = FontWeight.Bold)
            l.keyPoints.forEach { Text("- $it") }
            Button(onClick = { repo.toggleDone(l.id); done = !done }, modifier = Modifier.fillMaxWidth()) {
                Text(if (done) "Completed (tap to undo)" else "Mark lesson as completed")
            }
            Text("My notes", fontWeight = FontWeight.Bold)
            OutlinedTextField(value = note, onValueChange = { note = it; saved = false },
                label = { Text("Write your own notes") }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp))
            Button(onClick = { repo.setNote(l.id, note); saved = true }, modifier = Modifier.fillMaxWidth()) {
                Text(if (saved) "Saved" else "Save note")
            }
            Text(DISCLAIMER, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun QuizScreen(repo: Repo, label: String, qs: List<Question>, timeLimit: Int, onBack: () -> Unit, onFinish: (List<Int>) -> Unit) {
    if (qs.isEmpty()) {
        Column(Modifier.padding(16.dp)) { TopBar(label, onBack); Text("No questions to show.") }
        return
    }
    var i by remember { mutableStateOf(0) }
    val picked = remember { mutableStateListOf<Int>().apply { repeat(qs.size) { add(-1) } } }
    var bmTick by remember { mutableStateOf(0) }
    fun finish() {
        val list = picked.toList()
        val correct = qs.indices.count { list[it] == qs[it].answer }
        repo.addResult(label, qs.size, correct)
        onFinish(list)
    }
    var remaining by remember { mutableStateOf(timeLimit) }
    if (timeLimit > 0) {
        LaunchedEffect(Unit) {
            while (remaining > 0) { delay(1000); remaining -= 1 }
            finish()
        }
    }
    val q = qs[i]
    val chosen = picked[i]
    val bookmarked = remember(bmTick, q.id) { q.id in repo.bookmarks() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("$label  |  ${i + 1} of ${qs.size}", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
            TextButton(onClick = { repo.toggleBookmark(q.id); bmTick++ }) { Text(if (bookmarked) "Bookmarked" else "Bookmark") }
        }
        if (timeLimit > 0) Text("Time left: ${remaining / 60}:${(remaining % 60).toString().padStart(2, '0')}", fontWeight = FontWeight.Bold)
        LinearProgressIndicator(progress = { (i + 1f) / qs.size }, modifier = Modifier.fillMaxWidth())
        Text("${q.subject} - ${q.topic}  (${q.difficulty})", style = MaterialTheme.typography.bodySmall)
        Text(q.text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (repo.teluguOn() && q.textTe.isNotBlank()) Text(q.textTe)
        q.options.forEachIndexed { idx, opt ->
            val container = when {
                chosen == -1 -> MaterialTheme.colorScheme.surface
                idx == q.answer -> Color(0xFFCFEFDD)
                idx == chosen -> Color(0xFFF8D3D3)
                else -> MaterialTheme.colorScheme.surface
            }
            val textColor = if (chosen != -1 && (idx == q.answer || idx == chosen)) Color(0xFF101010) else MaterialTheme.colorScheme.onSurface
            Card(
                Modifier.fillMaxWidth().clickable(enabled = chosen == -1) {
                    picked[i] = idx
                    repo.recordAnswer(q.id, idx == q.answer)
                },
                colors = CardDefaults.cardColors(containerColor = container),
                elevation = CardDefaults.cardElevation(1.dp)
            ) { Text("${'A' + idx}.  $opt", Modifier.padding(14.dp), color = textColor) }
        }
        if (chosen != -1) {
            InfoCard {
                Text(if (chosen == q.answer) "Correct" else "Incorrect - correct answer: ${'A' + q.answer}", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(q.explanation)
                if (repo.teluguOn() && q.explanationTe.isNotBlank()) Text(q.explanationTe)
                Spacer(Modifier.height(4.dp))
                Text(q.reference, style = MaterialTheme.typography.bodySmall)
            }
            val last = i == qs.size - 1
            Button(onClick = {
                if (last) finish() else i++
            }, modifier = Modifier.fillMaxWidth()) { Text(if (last) "Finish and see results" else "Next question") }
        } else {
            Text("Select an answer to see feedback.", style = MaterialTheme.typography.bodySmall)
        }
        TextButton(onClick = onBack) { Text("Quit quiz") }
    }
}

@Composable
fun ResultScreen(label: String, qs: List<Question>, picked: List<Int>, onHome: () -> Unit, onRetryWrong: () -> Unit) {
    val correct = qs.indices.count { picked[it] == qs[it].answer }
    val wrong = qs.size - correct
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { TopBar("Results", null) }
        item {
            InfoCard {
                Text(label, fontWeight = FontWeight.Bold)
                Text("Score: $correct / ${qs.size}  (${if (qs.isEmpty()) 0 else correct * 100 / qs.size}%)", style = MaterialTheme.typography.headlineSmall)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onRetryWrong, enabled = wrong > 0, modifier = Modifier.weight(1f)) { Text("Retry wrong ($wrong)") }
                OutlinedButton(onClick = onHome, modifier = Modifier.weight(1f)) { Text("Home") }
            }
        }
        items(qs.indices.toList()) { idx ->
            val q = qs[idx]; val p = picked[idx]
            InfoCard {
                Text("${idx + 1}. ${q.text}", fontWeight = FontWeight.SemiBold)
                Text("Your answer: ${if (p < 0) "not answered" else q.options[p]}")
                Text("Correct answer: ${q.options[q.answer]}")
                Spacer(Modifier.height(4.dp))
                Text(q.explanation, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun BookmarksScreen(repo: Repo, onBack: () -> Unit) {
    var tick by remember { mutableStateOf(0) }
    val ids = remember(tick) { repo.bookmarks() }
    val list = repo.questions.filter { it.id in ids }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { TopBar("Bookmarks", onBack) }
        if (list.isEmpty()) item { Text("No bookmarks yet. Tap Bookmark while answering a question to save it here.") }
        items(list) { q ->
            InfoCard {
                Text("${q.subject} - ${q.topic}", style = MaterialTheme.typography.bodySmall)
                Text(q.text, fontWeight = FontWeight.SemiBold)
                Text("Answer: ${q.options[q.answer]}")
                Text(q.explanation, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { repo.toggleBookmark(q.id); tick++ }) { Text("Remove bookmark") }
            }
        }
    }
}

@Composable
fun AboutScreen(repo: Repo, onBack: () -> Unit, onHome: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    var te by remember { mutableStateOf(repo.teluguOn()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Settings, privacy and about", onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("About", fontWeight = FontWeight.Bold)
            Text("PRASUNI v0.2.0 - 1,000 practice questions and a few sample lessons. Content is labelled where it still needs review by a qualified nursing educator. Curriculum varies by university; verify against your syllabus.")
            Text("Privacy", fontWeight = FontWeight.Bold)
            Text("No account, no internet access, no ads, no analytics. Your answers, bookmarks and results are stored only on this device.")
            Text(DISCLAIMER, style = MaterialTheme.typography.bodySmall)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Show Telugu translations where available (none added yet)", Modifier.weight(1f))
                Switch(checked = te, onCheckedChange = { te = it; repo.setTelugu(it) })
            }
            Button(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Clear my personal data") }
            Text("Created by Pranitha", Modifier.fillMaxWidth().padding(top = 16.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Clear all data?") },
        text = { Text("This deletes your quiz history, bookmarks and statistics from this device. It cannot be undone.") },
        confirmButton = { TextButton(onClick = { repo.clearAllPersonalData(); confirm = false; onHome() }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
}
