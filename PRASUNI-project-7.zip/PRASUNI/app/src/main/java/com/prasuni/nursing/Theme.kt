package com.prasuni.nursing

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B2F5B)
val Teal = Color(0xFF0E9AA7)
val Green = Color(0xFF2E9E6B)

private val Light = lightColorScheme(
    primary = Navy, secondary = Teal, tertiary = Green,
    background = Color(0xFFF7FAFC), surface = Color.White,
    primaryContainer = Color(0xFFDCEBFA), onPrimaryContainer = Navy
)
private val Dark = darkColorScheme(
    primary = Color(0xFF7CC4F5), secondary = Color(0xFF55D0DA), tertiary = Color(0xFF6FD6A3),
    background = Color(0xFF0A1622), surface = Color(0xFF12253A),
    primaryContainer = Color(0xFF173A5E), onPrimaryContainer = Color.White
)

@Composable
fun PrasuniTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
